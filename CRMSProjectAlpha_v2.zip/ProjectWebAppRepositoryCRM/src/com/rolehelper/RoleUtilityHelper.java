package com.rolehelper;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Transaction;

import com.crm.models.CRM_Administrator;
import com.crm.utility.HibernateUtilityHelper;

public class RoleUtilityHelper {
	
	int employeeid;
	
	public  boolean manageroleprivilege(int employeeid){
		boolean managerolesratus=false;
		
        org.hibernate.Session hibernatesession=HibernateUtilityHelper.getHibernateSession();
		
		//Transaction tx=hibernatesession.beginTransaction();
		
		String sql="from CRM_Administrator where employee_id=:eid";
		
		Query query=hibernatesession.createQuery(sql);
		
		query.setInteger("eid", employeeid);
		
		@SuppressWarnings("unchecked")
		List<CRM_Administrator> listrole=query.list();
		
         if(!listrole.isEmpty()){
			
			 managerolesratus=listrole.get(0).getRoles().get(0).isPriv_manage_roles();
			 hibernatesession.close();
			 return managerolesratus;
			
         }
         hibernatesession.close();
		return managerolesratus;
	}
	public boolean manageviewcustomerprivilege(int employeeid){
		boolean managerolesratus=false;
		
        org.hibernate.Session hibernatesession=HibernateUtilityHelper.getHibernateSession();
		
		//Transaction tx=hibernatesession.beginTransaction();
		
		String sql="from CRM_Administrator where employee_id=:eid";
		
		Query query=hibernatesession.createQuery(sql);
		
		query.setInteger("eid", employeeid);
		
		@SuppressWarnings("unchecked")
		List<CRM_Administrator> listrole=query.list();
		
         if(!listrole.isEmpty()){
			
			 managerolesratus=listrole.get(0).getRoles().get(0).isView_customer_complaint();
			 hibernatesession.close();
			 return managerolesratus;
			
         }
         hibernatesession.close();
		return managerolesratus;
	}
	public boolean managepassinvestigatorprivilege(int employeeid){
		boolean managerolesratus=false;
		
        org.hibernate.Session hibernatesession=HibernateUtilityHelper.getHibernateSession();
		
		//Transaction tx=hibernatesession.beginTransaction();
		
		String sql="from CRM_Administrator where employee_id=:eid";
		
		Query query=hibernatesession.createQuery(sql);
		
		query.setInteger("eid", employeeid);
		
		@SuppressWarnings("unchecked")
		List<CRM_Administrator> listrole=query.list();
		
         if(!listrole.isEmpty()){
			
			 managerolesratus=listrole.get(0).getRoles().get(0).isPriv_pass_investigator();
			 hibernatesession.close();
			 return managerolesratus;
			
         }
         hibernatesession.close();
		return managerolesratus;
	}
	public boolean managesolvecomplaintsprivilege(int employeeid){
		boolean managerolesratus=false;
		
        org.hibernate.Session hibernatesession=HibernateUtilityHelper.getHibernateSession();
		
		//Transaction tx=hibernatesession.beginTransaction();
		
		String sql="from CRM_Administrator where employee_id=:eid";
		
		Query query=hibernatesession.createQuery(sql);
		
		query.setInteger("eid", employeeid);
		
		@SuppressWarnings("unchecked")
		List<CRM_Administrator> listrole=query.list();
		
         if(!listrole.isEmpty()){
			
			 managerolesratus=listrole.get(0).getRoles().get(0).isPriv_solve_complaint();
			 hibernatesession.close();
			 return managerolesratus;
			
         }
         hibernatesession.close();
		return managerolesratus;
	}
	public boolean manageclosecomplaintsprivilege(int employeeid){
		boolean managerolesratus=false;
		
        org.hibernate.Session hibernatesession=HibernateUtilityHelper.getHibernateSession();
		
		//Transaction tx=hibernatesession.beginTransaction();
		
		String sql="from CRM_Administrator where employee_id=:eid";
		
		Query query=hibernatesession.createQuery(sql);
		
		query.setInteger("eid", employeeid);
		
		@SuppressWarnings("unchecked")
		List<CRM_Administrator> listrole=query.list();
		
         if(!listrole.isEmpty()){
			
			 managerolesratus=listrole.get(0).getRoles().get(0).isPriv_close_complaint();
			 hibernatesession.close();
			 return managerolesratus;
			
         }
         hibernatesession.close();
		return managerolesratus;
	}
	public  boolean manageescalationprivilege(int employeeid){
		boolean managerolesratus=false;
		
        org.hibernate.Session hibernatesession=HibernateUtilityHelper.getHibernateSession();
		
		//Transaction tx=hibernatesession.beginTransaction();
		
		String sql="from CRM_Administrator where employee_id=:eid";
		
		Query query=hibernatesession.createQuery(sql);
		
		query.setInteger("eid", employeeid);
		
		@SuppressWarnings("unchecked")
		List<CRM_Administrator> listrole=query.list();
		
         if(!listrole.isEmpty()){
			
			 managerolesratus=listrole.get(0).getRoles().get(0).isPriv_escalate_priority();
			 hibernatesession.close();
			 return managerolesratus;
			
         }
         hibernatesession.close();
		return managerolesratus;
	}
	public  boolean managecomplaintprivilege(int employeeid){
		boolean managerolesratus=false;
		
        org.hibernate.Session hibernatesession=HibernateUtilityHelper.getHibernateSession();
		
		//Transaction tx=hibernatesession.beginTransaction();
		
		String sql="from CRM_Administrator where employee_id=:eid";
		
		Query query=hibernatesession.createQuery(sql);
		
		query.setInteger("eid", employeeid);
		
		@SuppressWarnings("unchecked")
		List<CRM_Administrator> listrole=query.list();
		
         if(!listrole.isEmpty()){
			
			 managerolesratus=listrole.get(0).getRoles().get(0).isPriv_manage_complaints();
			 hibernatesession.close();
			 return managerolesratus;
			
         }
         hibernatesession.close();
		return managerolesratus;
	}
	public boolean managecustomerprivilege(int employeeid){
		boolean managecustomerstatus=false;
		
        org.hibernate.Session hibernatesession=HibernateUtilityHelper.getHibernateSession();
		
		//Transaction tx=hibernatesession.beginTransaction();
		
		String sql="from CRM_Administrator where employee_id=:eid";
		
		Query query=hibernatesession.createQuery(sql);
		
		query.setInteger("eid", employeeid);
		
		@SuppressWarnings("unchecked")
		List<CRM_Administrator> listrole=query.list();
		
         if(!listrole.isEmpty()){
			
        	 managecustomerstatus=listrole.get(0).getRoles().get(0).isPriv_manage_customer();
			 hibernatesession.close();
			 return managecustomerstatus;
			
         }
         hibernatesession.close();
		return managecustomerstatus;
	}

}
