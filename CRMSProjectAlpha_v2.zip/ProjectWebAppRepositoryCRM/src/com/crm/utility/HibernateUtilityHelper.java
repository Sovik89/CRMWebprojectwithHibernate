package com.crm.utility;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateUtilityHelper {

	public static Session getHibernateSession(){
		Configuration config=new Configuration();
		config.configure();  // it will load configuration from hibernate.cfg.xml file
		
		SessionFactory factory=config.buildSessionFactory();
		Session hibernatesession=factory.openSession();
		
		return hibernatesession;
	}
}
