package com.crm.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="crm_solutions")
public class CRM_Solutions {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int solution_id;
	private String customer_first_name;
	private String customer_last_name;
	private String warranty_validity;
	private int estimated_solution_period;
	private String investigator_name;
	private String solution_body;
	private int order_no;
	private String product_name;
	
	@ManyToOne
    @JoinColumn(name = "customer_id")
	private CRM_Users user;
	
	@ManyToOne
    @JoinColumn(name = "complaint_id")
	private CRM_Complaints complaints;
	
	
	@ManyToOne
    @JoinColumn(name = "product_id")
	private CRM_Products products;
	
	
	public String getWarranty_validity() {
		return warranty_validity;
	}
	public void setWarranty_validity(String warranty_validity) {
		this.warranty_validity = warranty_validity;
	}
	public int getEstimated_solution_period() {
		return estimated_solution_period;
	}
	public void setEstimated_solution_period(int estimated_solution_period) {
		this.estimated_solution_period = estimated_solution_period;
	}
	public String getInvestigator_name() {
		return investigator_name;
	}
	public void setInvestigator_name(String investigator_name) {
		this.investigator_name = investigator_name;
	}
	public CRM_Users getUser() {
		return user;
	}
	public void setUser(CRM_Users user) {
		this.user = user;
	}
	public CRM_Complaints getComplaints() {
		return complaints;
	}
	public void setComplaints(CRM_Complaints complaints) {
		this.complaints = complaints;
	}
	public CRM_Products getProducts() {
		return products;
	}
	public void setProducts(CRM_Products products) {
		this.products = products;
	}
	
	public String getProduct_name() {
		return product_name;
	}
	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}
	public int getOrder_no() {
		return order_no;
	}
	public void setOrder_no(int order_no) {
		this.order_no = order_no;
	}
	public String getSolution_body() {
		return solution_body;
	}
	public void setSolution_body(String solution_body) {
		this.solution_body = solution_body;
	}
	public int getSolution_id() {
		return solution_id;
	}
	public void setSolution_id(int solution_id) {
		this.solution_id = solution_id;
	}
	public String getCustomer_first_name() {
		return customer_first_name;
	}
	public void setCustomer_first_name(String customer_first_name) {
		this.customer_first_name = customer_first_name;
	}
	public String getCustomer_last_name() {
		return customer_last_name;
	}
	public void setCustomer_last_name(String customer_last_name) {
		this.customer_last_name = customer_last_name;
	}
	
	
	
}
