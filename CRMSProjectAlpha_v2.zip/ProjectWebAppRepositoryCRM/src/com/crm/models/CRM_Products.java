package com.crm.models;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;

//import model.Courses;

@Entity
@Table(name="crm_products")
public class CRM_Products {

	@Id//@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int product_id;
	private String product_name;
	private int warranty;
	
	
	@OneToMany(targetEntity=CRM_Complaints.class,fetch=FetchType.LAZY,mappedBy="products",cascade=CascadeType.ALL)
	private List<CRM_Complaints> complaintslist=new ArrayList<CRM_Complaints>();
	
	@OneToMany(targetEntity=CRM_Solutions.class,fetch=FetchType.LAZY,mappedBy="products",cascade=CascadeType.ALL)
	private List<CRM_Solutions> solutionlist=new ArrayList<CRM_Solutions>();
	
	public List<CRM_Solutions> getSolutionlist() {
		return solutionlist;
	}
	public void setSolutionlist(List<CRM_Solutions> solutionlist) {
		this.solutionlist = solutionlist;
	}
	public int getProduct_id() {
		return product_id;
	}
	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}
	public String getProduct_name() {
		return product_name;
	}
	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}
	public int getWarranty() {
		return warranty;
	}
	public void setWarranty(int warranty) {
		this.warranty = warranty;
	}
	@OneToMany
	@JoinTable(name = "crm_compaints", joinColumns = { @JoinColumn(name = "product_id") })
	public List<CRM_Complaints> getComplaintslist() {
		return complaintslist;
	}
	public void setComplaintslist(List<CRM_Complaints> complaintslist) {
		this.complaintslist = complaintslist;
	}
	
	
	
	
}
