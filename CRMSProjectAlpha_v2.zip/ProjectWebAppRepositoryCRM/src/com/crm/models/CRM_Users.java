package com.crm.models;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.JoinColumn;


@Entity(name="crm_user")
public class CRM_Users {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int user_id;
	private String username;
	private String password;
	private String first_name;
	private String last_name;
	private Date date_of_birth;
	private Long phone_number;
	private String email_address;
	private String city;
	private String state;
	private String country;
	private String address;
	
	@OneToMany(targetEntity=CRM_Reviews.class,fetch=FetchType.LAZY,mappedBy="users",cascade=CascadeType.ALL)
	private List<CRM_Reviews> reviewlist=new ArrayList<CRM_Reviews>();
	
	@OneToMany(targetEntity=CRM_Complaints.class,fetch=FetchType.LAZY,mappedBy="users",cascade=CascadeType.ALL)
	private List<CRM_Complaints> complaints = new ArrayList<CRM_Complaints>();
	
	@OneToMany(targetEntity=CRM_Solutions.class,fetch=FetchType.LAZY,mappedBy="user",cascade=CascadeType.ALL)
	private List<CRM_Solutions> solutions = new ArrayList<CRM_Solutions>();
	
	
	
	
	
	public List<CRM_Solutions> getSolutions() {
		return solutions;
	}
	public void setSolutions(List<CRM_Solutions> solutions) {
		this.solutions = solutions;
	}
	public List<CRM_Reviews> getReviewlist() {
		return reviewlist;
	}
	public void setReviewlist(List<CRM_Reviews> reviewlist) {
		this.reviewlist = reviewlist;
	}
	public List<CRM_Complaints> getComplaints() {
		return complaints;
	}
	public void setComplaints(List<CRM_Complaints> complaints) {
		this.complaints = complaints;
	}
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	public Date getDate_of_birth() {
		return date_of_birth;
	}
	public void setDate_of_birth(Date date_of_birth) {
		this.date_of_birth = date_of_birth;
	}
	public Long getPhone_number() {
		return phone_number;
	}
	public void setPhone_number(Long phone_number) {
		this.phone_number = phone_number;
	}
	public String getEmail_address() {
		return email_address;
	}
	public void setEmail_address(String email_address) {
		this.email_address = email_address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "crm_compaints", joinColumns = { @JoinColumn(name = "user_id") })
	public  List<CRM_Complaints> getcomplaints() {
		return this.complaints;
	}

	public void setcomplaints(List<CRM_Complaints> complaints) {
		this.complaints = complaints;
	}
}
