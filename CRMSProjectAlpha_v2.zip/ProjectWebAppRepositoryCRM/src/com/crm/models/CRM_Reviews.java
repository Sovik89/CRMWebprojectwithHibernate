package com.crm.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="crm_reviews")
public class CRM_Reviews {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int review_id;
	private String review;
	//private int user_id;
	//private int admin_id;
	
	@ManyToOne
    @JoinColumn(name = "employee_id")
	private CRM_Administrator admin;
	
	@ManyToOne
    @JoinColumn(name = "user_id")
	private CRM_Users users;
	
	
	public CRM_Administrator getAdmin() {
		return admin;
	}
	public void setAdmin(CRM_Administrator admin) {
		this.admin = admin;
	}
	public CRM_Users getUsers() {
		return users;
	}
	public void setUsers(CRM_Users users) {
		this.users = users;
	}
	public int getReview_id() {
		return review_id;
	}
	public void setReview_id(int review_id) {
		this.review_id = review_id;
	}
	public String getReview() {
		return review;
	}
	public void setReview(String review) {
		this.review = review;
	}
	
	
	
}
