package com.crm.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

@Entity
@Table(name="crm_roles")
public class CRM_Roles {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int role_id;
	private String role_name;
	@Column(nullable = false)
	@Type(type = "org.hibernate.type.NumericBooleanType")
	private boolean priv_manage_customer;
	
	@Column(nullable = false)
	@Type(type = "org.hibernate.type.NumericBooleanType")
	private boolean priv_manage_complaints;
	
	@Column(nullable = false)
	@Type(type = "org.hibernate.type.NumericBooleanType")
	private boolean priv_solve_complaint;
	
	@Column(nullable = false)
	@Type(type = "org.hibernate.type.NumericBooleanType")
	private boolean priv_pass_investigator;
	
	@Column(nullable = false)
	@Type(type = "org.hibernate.type.NumericBooleanType")
	private boolean priv_close_complaint;
	
	@Column(nullable = false)
	@Type(type = "org.hibernate.type.NumericBooleanType")
	private boolean view_customer_complaint;
	
	@Column(nullable = false)
	@Type(type = "org.hibernate.type.NumericBooleanType")
	private boolean priv_escalate_priority;
	
	@Column(nullable = false)
	@Type(type = "org.hibernate.type.NumericBooleanType")
	private boolean priv_manage_roles;
	
	@ManyToOne
    @JoinColumn(name = "emp_id")
	private CRM_Administrator admin;
	
	
	
	public CRM_Administrator getAdmin() {
		return admin;
	}
	public void setAdmin(CRM_Administrator admin) {
		this.admin = admin;
	}
	public int getRole_id() {
		return role_id;
	}
	public void setRole_id(int role_id) {
		this.role_id = role_id;
	}
	public String getRole_name() {
		return role_name;
	}
	public void setRole_name(String role_name) {
		this.role_name = role_name;
	}
	public boolean isPriv_manage_customer() {
		return priv_manage_customer;
	}
	public void setPriv_manage_customer(boolean priv_manage_customer) {
		this.priv_manage_customer = priv_manage_customer;
	}
	public boolean isPriv_manage_complaints() {
		return priv_manage_complaints;
	}
	public void setPriv_manage_complaints(boolean priv_manage_complaints) {
		this.priv_manage_complaints = priv_manage_complaints;
	}
	public boolean isPriv_solve_complaint() {
		return priv_solve_complaint;
	}
	public void setPriv_solve_complaint(boolean priv_solve_complaint) {
		this.priv_solve_complaint = priv_solve_complaint;
	}
	public boolean isPriv_pass_investigator() {
		return priv_pass_investigator;
	}
	public void setPriv_pass_investigator(boolean priv_pass_investigator) {
		this.priv_pass_investigator = priv_pass_investigator;
	}
	public boolean isPriv_close_complaint() {
		return priv_close_complaint;
	}
	public void setPriv_close_complaint(boolean priv_close_complaint) {
		this.priv_close_complaint = priv_close_complaint;
	}
	public boolean isView_customer_complaint() {
		return view_customer_complaint;
	}
	public void setView_customer_complaint(boolean view_customer_complaint) {
		this.view_customer_complaint = view_customer_complaint;
	}
	public boolean isPriv_escalate_priority() {
		return priv_escalate_priority;
	}
	public void setPriv_escalate_priority(boolean priv_escalate_priority) {
		this.priv_escalate_priority = priv_escalate_priority;
	}
	public boolean isPriv_manage_roles() {
		return priv_manage_roles;
	}
	public void setPriv_manage_roles(boolean priv_manage_roles) {
		this.priv_manage_roles = priv_manage_roles;
	}
	
	
	
}
