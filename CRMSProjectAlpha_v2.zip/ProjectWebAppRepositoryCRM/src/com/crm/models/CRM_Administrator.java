package com.crm.models;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;



@Entity
@Table(name="crm_administrator")
public class CRM_Administrator {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int employee_id;
	private String username;
	private String pasword;
	private String employee_name;
	
	
	@OneToMany(targetEntity=CRM_Roles.class,fetch=FetchType.LAZY,mappedBy="admin",cascade=CascadeType.ALL)
	private List<CRM_Roles> roles=new ArrayList<CRM_Roles>();
	
	@OneToMany(targetEntity=CRM_Reviews.class,fetch=FetchType.LAZY,mappedBy="admin",cascade=CascadeType.ALL)
	private List<CRM_Reviews> reviewlist=new ArrayList<CRM_Reviews>(); 
	
	/*@OneToMany(targetEntity=CRM_Solutions.class,fetch=FetchType.LAZY,mappedBy="admin",cascade=CascadeType.ALL)
	private List<CRM_Solutions> solutionlist=new ArrayList<CRM_Solutions>();
	
	
	
	
	public List<CRM_Solutions> getSolutionlist() {
		return solutionlist;
	}
	public void setSolutionlist(List<CRM_Solutions> solutionlist) {
		this.solutionlist = solutionlist;*/
	
	public List<CRM_Reviews> getReviewlist() {
		return reviewlist;
	}
	public void setReviewlist(List<CRM_Reviews> reviewlist) {
		this.reviewlist = reviewlist;
	}
	public List<CRM_Roles> getRoles() {
		return roles;
	}
	public void setRoles(List<CRM_Roles> roles) {
		this.roles = roles;
	}
	public int getEmployee_id() {
		return employee_id;
	}
	public void setEmployee_id(int employee_id) {
		this.employee_id = employee_id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPasword() {
		return pasword;
	}
	public void setPasword(String pasword) {
		this.pasword = pasword;
	}
	public String getEmployee_name() {
		return employee_name;
	}
	public void setEmployee_name(String employee_name) {
		this.employee_name = employee_name;
	}
	
		
	
}
