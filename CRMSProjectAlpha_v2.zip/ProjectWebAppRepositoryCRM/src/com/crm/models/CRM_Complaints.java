package com.crm.models;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="crm_compaints")
public class CRM_Complaints {
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
	private int complaint_id;
	//private int uId;
	//private int productId;
	private String product_name;
	private long lot_no;
	private long order_no;
	
	private Date purchase_date;
	private String summary;
	private Date date_of_issue;
	private String complaint_status;
	private String priority;
	
	
	@ManyToOne
    @JoinColumn(name = "user_id")
	private CRM_Users users;
	
	@ManyToOne
    @JoinColumn(name = "product_id")
	private CRM_Products products;
	
	@OneToMany(targetEntity=CRM_Solutions.class,fetch=FetchType.LAZY,mappedBy="complaints",cascade=CascadeType.ALL)
	private List<CRM_Solutions> solutionlist=new ArrayList<CRM_Solutions>();
	
	
	
	
	public CRM_Users getUsers() {
		return users;
	}
	public void setUsers(CRM_Users users) {
		this.users = users;
	}
	public CRM_Products getProducts() {
		return products;
	}
	public void setProducts(CRM_Products products) {
		this.products = products;
	}
	
	
	public List<CRM_Solutions> getSolutionlist() {
		return solutionlist;
	}
	public void setSolutionlist(List<CRM_Solutions> solutionlist) {
		this.solutionlist = solutionlist;
	}
	public int getComplaintId() {
		return complaint_id;
	}
	public void setComplaintId(int complaint_id) {
		this.complaint_id = complaint_id;
	}
	
	public long getOrder_no() {
		return order_no;
	}
	public void setOrder_no(long order_no) {
		this.order_no = order_no;
	}
	/*
	public int getuId() {
		return uId;
	}
	public void setuId(int uId) {
		this.uId = uId;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}*/
	public String getProductName() {
		return product_name;
	}
	public void setProductName(String product_name) {
		this.product_name = product_name;
	}
	public long getLotNo() {
		return lot_no;
	}
	public void setLotNo(long lot_no) {
		this.lot_no = lot_no;
	}
	/*public Date getPurchasedate() {
		return purchasedate;
	}
	public void setPurchasedate(Date purchasedate) {
		this.purchasedate = purchasedate;
	}*/
	public String getSummary() {
		return summary;
	}
	public int getComplaint_id() {
		return complaint_id;
	}
	public void setComplaint_id(int complaint_id) {
		this.complaint_id = complaint_id;
	}
	public String getProduct_name() {
		return product_name;
	}
	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}
	public long getLot_no() {
		return lot_no;
	}
	public void setLot_no(long lot_no) {
		this.lot_no = lot_no;
	}
	public Date getPurchase_date() {
		return purchase_date;
	}
	public void setPurchase_date(Date purchase_date) {
		this.purchase_date = purchase_date;
	}
	public void setSummary(String summary) {
		this.summary = summary;
	}
	public Date getDate_of_issue() {
		return date_of_issue;
	}
	public void setDate_of_issue(Date date_of_issue) {
		this.date_of_issue = date_of_issue;
	}
	public String getComplaint_status() {
		return complaint_status;
	}
	public void setComplaint_status(String complaint_status) {
		this.complaint_status = complaint_status;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	
	
	
}
