package com.crm.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Query;
import org.hibernate.Transaction;

import com.crm.utility.HibernateUtilityHelper;
import com.rolehelper.RoleUtilityHelper;

/**
 * Servlet implementation class EditComplaintServlet
 */
@WebServlet("/EditComplaintServlet")
public class EditComplaintServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditComplaintServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	    int complaintid=Integer.parseInt(request.getParameter("id"));
	    String complaintstatus=request.getParameter("status");
	    String priority=request.getParameter("priority");
	    String investigator=request.getParameter("invi");
	    PrintWriter pw=response.getWriter();
	    pw.println("complaintid"+complaintid);
	    
        org.hibernate.Session hibernatesession=HibernateUtilityHelper.getHibernateSession();
		
		Transaction tx=hibernatesession.beginTransaction();
	/*	javax.servlet.http.HttpSession adminsession=request.getSession(false);
		int empid=(int) adminsession.getAttribute("adminid");
	    
	RoleUtilityHelper roleutility=new RoleUtilityHelper();
		
		boolean ispriviledge=roleutility.manageroleprivilege(empid);
		
		  if(ispriviledge==true){
		*/
		  String hql="UPDATE CRM_Compaints set "+"complaint_status = :costat,"+"priority = :pr,"+"investigator_name = :in "+"where complaint_id= :cid";
		  
		  Query queryinsert=hibernatesession.createSQLQuery(hql);
		  queryinsert.setParameter("costat", complaintstatus);
		  queryinsert.setParameter("pr", priority);
		  queryinsert.setParameter("in", investigator);
		  queryinsert.setParameter("cid", complaintid);
		  queryinsert.executeUpdate();
		  hibernatesession.close();
		  tx.commit();
		  RequestDispatcher rd=request.getRequestDispatcher("admincomplaintstatus.jsp");
		  rd.forward(request, response);
		  
		  	

	    
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
