package com.crm.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Transaction;

import com.crm.models.CRM_Complaints;
import com.crm.models.CRM_Products;
import com.crm.models.CRM_Solutions;
import com.crm.models.CRM_Users;
import com.crm.utility.HibernateUtilityHelper;

/**
 * Servlet implementation class CreateSolutionServlet
 */
@WebServlet("/CreateSolutionServlet")
public class CreateSolutionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CreateSolutionServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		int complaintid=Integer.parseInt(request.getParameter("complaintid"));
		int productid=Integer.parseInt(request.getParameter("productid"));
		int userid=Integer.parseInt(request.getParameter("userid"));
		String firstname=request.getParameter("fname");
		String lastname=request.getParameter("lname");
		String productname=request.getParameter("productname");
		//int lotnumber=Integer.parseInt(request.getParameter("lotno"));
		int ordernumber=Integer.parseInt(request.getParameter("orderno"));
		String realsoln=request.getParameter("solnsummary");
		String inviname=request.getParameter("investigatorname");
		int solutiontime=Integer.parseInt(request.getParameter("solntime"));
		String validity_of_warranty=request.getParameter("wa_val");
		 javax.servlet.http.HttpSession usersession=request.getSession(false);
			//org.hibernate.SessionFactory factory=config.buildSessionFactory();
			org.hibernate.Session hibernatesession=HibernateUtilityHelper.getHibernateSession();
			//org.hibernate.Session inputSession=HibernateUtilityHelper.getHibernateSession();
			Transaction ts=hibernatesession.beginTransaction();
		    CRM_Products prod=new CRM_Products();
		    prod.setProduct_id(productid);
		    CRM_Users user=new CRM_Users();
		   user.setUser_id(userid);
		    
		    CRM_Complaints complaints=new CRM_Complaints();
		    complaints.setComplaint_id(complaintid);
		    CRM_Solutions solution=new CRM_Solutions();
		    solution.setCustomer_first_name(firstname);
		    solution.setCustomer_last_name(lastname);
		    solution.setProducts(prod);
		    solution.setUser(user);
		    solution.setComplaints(complaints);
		    solution.setInvestigator_name(inviname);
		    solution.setEstimated_solution_period(solutiontime);
		    solution.setOrder_no(ordernumber);
		    solution.setSolution_body(realsoln);
		    solution.setProduct_name(productname);
		    solution.setWarranty_validity(validity_of_warranty);
		    
		    hibernatesession.save(solution);
		    ts.commit();
		    
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
