package com.crm.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

//import javax.persistence.Query;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Query;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.crm.models.CRM_Users;


/**
 * Servlet implementation class UserLoginServlet
 */
@WebServlet("/UserLoginServlet")
public class UserLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserLoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		Configuration config=new Configuration().configure();
		String username1=request.getParameter("username");
		String password1=request.getParameter("password");
		org.hibernate.SessionFactory factory=config.buildSessionFactory();
		org.hibernate.Session hibernatesession=factory.openSession();
		//Transaction ts=hibernatesession.beginTransaction();
		String hql = "from crm_user where username like :username2 and password like :password2";
		Query query = hibernatesession.createQuery(hql);
		query.setString("username2", username1.toString());
		query.setString("password2", password1.toString());
		
		@SuppressWarnings("unchecked")
		List<CRM_Users> listuser=query.list();
		PrintWriter pw=response.getWriter();
		if(listuser.isEmpty()!=true){
			javax.servlet.http.HttpSession usersession=request.getSession();
			usersession.setAttribute("userid", listuser.get(0).getUser_id());
			usersession.setAttribute("username", listuser.get(0).getUsername());
			usersession.setAttribute("email", listuser.get(0).getEmail_address());
			usersession.setAttribute("firstname", listuser.get(0).getFirst_name());
			usersession.setAttribute("lastname", listuser.get(0).getLast_name());
			
			//pw.println(listuser.get(0).getUsername());
			//pw.println(listuser.get(0).getPassword());
			RequestDispatcher rd=request.getRequestDispatcher("userprofile.jsp");
			hibernatesession.close();
			rd.forward(request, response);
		  			
		}else{
			hibernatesession.close();
			response.setContentType("text/html");  
			 pw.println("<script type=\"text/javascript\">");
			 pw.println("alert('User or password incorrect');");
			 pw.println("location='login.html';");
			 pw.println("</script>");
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
