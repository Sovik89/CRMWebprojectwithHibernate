package com.crm.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
//import javax.transaction.Transaction;

import org.hibernate.Transaction;

import com.crm.models.CRM_Reviews;
import com.crm.utility.HibernateUtilityHelper;

/**
 * Servlet implementation class ProvideReviewServlet
 */
@WebServlet("/ProvideReviewServlet")
public class ProvideReviewServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProvideReviewServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		int userid=Integer.parseInt(request.getParameter("userid"));
		String review=request.getParameter("review").trim();
		org.hibernate.Session hibernatesession=HibernateUtilityHelper.getHibernateSession();
		Transaction tx=hibernatesession.beginTransaction();
		
		CRM_Reviews reviews=new CRM_Reviews();
		
		reviews.setReview(review);
		reviews.getUsers().setUser_id(userid);
		
		hibernatesession.save(reviews);
		tx.commit();
	
		RequestDispatcher rd=request.getRequestDispatcher("userprofile.jsp");
		hibernatesession.close();
		rd.forward(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
