package com.crm.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.crm.models.CRM_Products;

/**
 * Servlet implementation class InsertProductServlet
 */
@WebServlet("/InsertProductServlet")
public class InsertProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InsertProductServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter pw=response.getWriter();
		
		int productid=Integer.parseInt(request.getParameter(("productid").toString()));
		String productname=request.getParameter("productname");
	    int warrantyperiod=Integer.parseInt(request.getParameter(("warranty_period").toString()));
	
	    Configuration config=new Configuration().configure();
	    org.hibernate.SessionFactory factory=config.buildSessionFactory();
	    org.hibernate.Session hibernatesession=factory.openSession();
	    
	    Transaction ts=hibernatesession.beginTransaction();
	    
	    
	    CRM_Products product=new CRM_Products();
	    product.setProduct_id(productid);
	    product.setProduct_name(productname);
	    product.setWarranty(warrantyperiod);
	    
	    hibernatesession.save(product);
	    ts.commit();
	    hibernatesession.close();
	    
	    RequestDispatcher rd=request.getRequestDispatcher("login.html");
	    rd.forward(request, response);
	    response.setContentType("text/html");  
		 pw.println("<script type=\"text/javascript\">");
		 pw.println("alert('Product inserted successfully');");
		// pw.println("location='login.html';");
		 pw.println("</script>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
