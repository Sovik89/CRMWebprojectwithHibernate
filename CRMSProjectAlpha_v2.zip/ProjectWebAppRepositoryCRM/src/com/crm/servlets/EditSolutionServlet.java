package com.crm.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Query;
import org.hibernate.Transaction;

import com.crm.utility.HibernateUtilityHelper;

/**
 * Servlet implementation class EditSolutionServlet
 */
@WebServlet("/EditSolutionServlet")
public class EditSolutionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditSolutionServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		  int solutionid=Integer.parseInt(request.getParameter("solutionid"));
		    int estimateddays=Integer.parseInt(request.getParameter("period"));
		    String investigatorname=request.getParameter("investigator");
		    PrintWriter pw=response.getWriter();
		   // pw.println("complaintid"+complaintid);
		    org.hibernate.Session hibernatesession=HibernateUtilityHelper.getHibernateSession();
			
			Transaction tx=hibernatesession.beginTransaction();
		/*	javax.servlet.http.HttpSession adminsession=request.getSession(false);
			int empid=(int) adminsession.getAttribute("adminid");
		    
		RoleUtilityHelper roleutility=new RoleUtilityHelper();
			
			boolean ispriviledge=roleutility.manageroleprivilege(empid);
			
			  if(ispriviledge==true){
			*/
			  String hql="UPDATE CRM_Solutions set "+"estimated_solution_period = :solper,"+"investigator_name = :in "+"where solution_id= :sid";
			  
			  Query queryinsert=hibernatesession.createSQLQuery(hql);
			  queryinsert.setParameter("solper", estimateddays);
			  queryinsert.setParameter("in", investigatorname);
			  queryinsert.setParameter("sid", solutionid);
			  queryinsert.executeUpdate();
			  hibernatesession.close();
			 // tx.commit();
			  RequestDispatcher rd=request.getRequestDispatcher("adminsolutionlist.jsp");
			  rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
