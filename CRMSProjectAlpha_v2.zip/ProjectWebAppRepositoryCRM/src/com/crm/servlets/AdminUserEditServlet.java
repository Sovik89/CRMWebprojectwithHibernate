package com.crm.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AdminUserEditServlet
 */
@WebServlet("/AdminUserEditServlet")
public class AdminUserEditServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminUserEditServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		int userid=Integer.parseInt(request.getParameter("userid"));
		String fname=request.getParameter("firstname");
		String lname=request.getParameter("lastname");
		String email=request.getParameter("email");
		String username=request.getParameter("username");
		
        org.hibernate.Session hibernatesession=HibernateUtilityHelper.getHibernateSession();
		
		Transaction tx=hibernatesession.beginTransaction();
		
		 String hql="UPDATE CRM_Users set "+"first_name = :fn,"+"last_name = :ln,"+"username = :uname,"+"email_address = :eadd "+"where user_id= :uid";
		
		 Query query=hibernatesession.createSQLQuery(hql);
		 
		 query.setParameter("fn",fname);
		 query.setParameter("ln",lname);
		 query.setParameter("eadd",email);
		 query.setParameter("uname",username);
		 query.setParameter("uid",userid);
		 query.executeUpdate();
		 hibernatesession.close();
		 RequestDispatcher rd=request.getRequestDispatcher("adminuserprofileview.jsp");
		  rd.forward(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
