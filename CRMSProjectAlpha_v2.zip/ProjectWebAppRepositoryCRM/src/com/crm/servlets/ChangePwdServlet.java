package com.crm.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Query;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.crm.models.CRM_Users;

/**
 * Servlet implementation class ChangePwdServlet
 */
@WebServlet("/ChangePwdServlet")
public class ChangePwdServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ChangePwdServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		Configuration config=new Configuration().configure();
		 // it will load configuration from hibernate.cfg.xml file
		
		
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		
		org.hibernate.SessionFactory factory=config.buildSessionFactory();
		org.hibernate.Session hibernatesession=factory.openSession();
		//org.hibernate.Session inputSession=HibernateUtilityHelper.getHibernateSession();
		Transaction ts=hibernatesession.beginTransaction();
		
		CRM_Users user=new CRM_Users();
		user.setUsername(username);
        user.setPassword(password);
        
        String hql = "UPDATE crm_user set password = :pwd "  + "WHERE username = :uname";
   Query query = hibernatesession.createQuery(hql);
   query.setParameter("pwd", password);
   query.setParameter("uname", username);
   ts.commit();
    PrintWriter pw=response.getWriter();    
   int result = query.executeUpdate();
   if(result!=0){
	   hibernatesession.close();
	   response.setContentType("text/html");  
		 pw.println("<script type=\"text/javascript\">");
		 pw.println("alert('Password Updated');");
		 pw.println("location='login.html';");
		 pw.println("</script>");
   } else{
	   
	   hibernatesession.close();
	   response.setContentType("text/html");  
		 pw.println("<script type=\"text/javascript\">");
		 pw.println("alert('Password Updated');");
		 pw.println("location='confirmpwd.jsp';");
		 pw.println("</script>");
   }
		
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
