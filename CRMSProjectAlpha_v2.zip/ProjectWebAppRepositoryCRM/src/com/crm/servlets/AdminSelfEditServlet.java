package com.crm.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Query;
import org.hibernate.Transaction;

import com.crm.models.CRM_Administrator;
import com.crm.utility.HibernateUtilityHelper;

/**
 * Servlet implementation class AdminSelfEditServlet
 */
@WebServlet("/AdminSelfEditServlet")
public class AdminSelfEditServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminSelfEditServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		
		int empid=Integer.parseInt(request.getParameter("employeeid"));
		String empname=request.getParameter("employeename");
		String uname=request.getParameter("username");
		String pwd=request.getParameter("password");
		
		org.hibernate.Session hibernatesession=HibernateUtilityHelper.getHibernateSession();
		Transaction tx =hibernatesession.beginTransaction();
		
		CRM_Administrator admin=new CRM_Administrator();
		PrintWriter pw=response.getWriter();
		admin.setEmployee_id(empid);
		admin.setEmployee_name(empname);
		admin.setUsername(uname);
		admin.setPasword(pwd);
		String hql="UPDATE CRM_Administrator set"+"employee_name=:emp_name,"+"username=:u_name,"+"pasword=:pwd1"+"where employee_id=:emp_id";
		
		Query query=hibernatesession.createQuery(hql);
		
		query.setParameter("emp_name", empname);
		query.setParameter("u_name", uname);
		query.setParameter("pwd1", pwd);
		query.setParameter("emp_id", empid);
	    tx.commit();
	    hibernatesession.close();
		
	    response.setContentType("text/html");  
		 pw.println("<script type=\"text/javascript\">");
		 pw.println("alert('Admin Updated');");
		 pw.println("location='adminlandingpage.jsp';");
		 pw.println("</script>");
		
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
