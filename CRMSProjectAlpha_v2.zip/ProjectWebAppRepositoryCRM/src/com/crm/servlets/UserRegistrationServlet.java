package com.crm.servlets;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.crm.models.CRM_Users;

/**
 * Servlet implementation class UserRegistrationServlet
 */
@WebServlet("/UserRegistrationServlet")
public class UserRegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserRegistrationServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		Configuration config=new Configuration().configure();
		 // it will load configuration from hibernate.cfg.xml file
		
		
		String username=request.getParameter("username");
		String fname=request.getParameter("fname");
		String lname=request.getParameter("lname");
		String email=request.getParameter("email");
		String password=request.getParameter("password");
		String cpassword=request.getParameter("password");
		String address=request.getParameter("address");
		String city=request.getParameter("city");
		String state=request.getParameter("state");
		String country=request.getParameter("country");
	try{
		DateFormat sf1=new SimpleDateFormat("MM/DD/yyyy");
		Date date=(Date) sf1.parse( request.getParameter("dob"));
	    java.sql.Date dob=new java.sql.Date(date.getTime());
		long phno=Long.parseLong(request.getParameter("phno"));
	
		
		
		org.hibernate.SessionFactory factory=config.buildSessionFactory();
		org.hibernate.Session hibernatesession=factory.openSession();
		//org.hibernate.Session inputSession=HibernateUtilityHelper.getHibernateSession();
		Transaction ts=hibernatesession.beginTransaction();
		
		CRM_Users users=new CRM_Users();
		users.setUsername(username);
		users.setFirst_name(fname);
		users.setLast_name(lname);
		users.setEmail_address(email);
		users.setPassword(password);
		users.setAddress(address);
		users.setCity(city);
		users.setState(state);
		users.setDate_of_birth(dob);
		users.setCountry(country);
		users.setPhone_number(phno);
		hibernatesession.save(users);
			ts.commit();
			
			RequestDispatcher rd=request.getRequestDispatcher("login.html");
			hibernatesession.close();
			rd.forward(request, response);
			//hibernatesession.close();
		
	}catch(Exception e){
		e.printStackTrace();
	}
		

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
