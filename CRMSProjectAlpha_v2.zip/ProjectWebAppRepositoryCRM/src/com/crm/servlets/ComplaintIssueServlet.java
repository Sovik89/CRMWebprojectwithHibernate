package com.crm.servlets;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Transaction;

import com.crm.models.CRM_Complaints;
import com.crm.models.CRM_Products;
import com.crm.models.CRM_Users;
import com.crm.utility.HibernateUtilityHelper;

/**
 * Servlet implementation class ComplaintIssueServlet
 */
@WebServlet("/ComplaintIssueServlet")
public class ComplaintIssueServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ComplaintIssueServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		int productid=Integer.parseInt(request.getParameter("productid"));
		String productname=request.getParameter("productname");
	    long lotno=Long.parseLong(request.getParameter("lotno"));
	    long order_no=Long.parseLong(request.getParameter("orderno"));
	    String summary=request.getParameter("summary");
	    
	    try{
			
			
		    DateFormat sf12=new SimpleDateFormat("mm/dd/yyyy");
			Date dateofpurchase=(Date) sf12.parse( request.getParameter("dop"));
		   // @SuppressWarnings("deprecation")
			//java.sql.Date dop=new java.sql.Date(dateofpurchase.getTime());
	    	/*List<String> st=new ArrayList<String>();
	    	String dt=request.getParameter("dop");
		    dt=dt.concat("/");
		    for(String z:dt.split("\\/")){
		    	st.add(z);
		    }
		    String date=st.get(2).toString()+"-"+st.get(1).toString()+"-"+st.get(0).toString();*/
		   
		    javax.servlet.http.HttpSession usersession=request.getSession(false);
			//org.hibernate.SessionFactory factory=config.buildSessionFactory();
			org.hibernate.Session hibernatesession=HibernateUtilityHelper.getHibernateSession();
			//org.hibernate.Session inputSession=HibernateUtilityHelper.getHibernateSession();
			Transaction ts=hibernatesession.beginTransaction();
		    CRM_Products prod=new CRM_Products();
		    prod.setProduct_id(productid);
		    CRM_Users user=new CRM_Users();
		   // user.setUser_id(Integer.parseInt(usersession.getAttribute("userid").toString()));
		    
		    CRM_Complaints complaints=new CRM_Complaints();
		   // complaints.setDate_of_issue(doi);
		    complaints.setPurchase_date(dateofpurchase);
		    complaints.setProductName(productname);
		    complaints.setProducts(prod);
		   // complaints.setPriority("Medium");
		    complaints.setLotNo(lotno);
		    complaints.setOrder_no(order_no);
		    complaints.setSummary(summary);
		    complaints.setComplaint_status("Issued");
		    complaints.setPriority("Medium");
		    hibernatesession.save(complaints);
		    
		    ts.commit();
		    hibernatesession.close();
		    
	    }catch(Exception e){
	    	e.printStackTrace();
	    }
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
