package com.crm.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
//import javax.transaction.Transaction;

import org.hibernate.Query;
import org.hibernate.Transaction;

import com.crm.models.CRM_Administrator;
import com.crm.utility.HibernateUtilityHelper;
import com.rolehelper.RoleUtilityHelper;

/**
 * Servlet implementation class EditProductServlet
 */
@WebServlet("/EditProductServlet")
public class EditProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditProductServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		int productid=Integer.parseInt(request.getParameter("productid"));
		String productname=request.getParameter("productname");
		int warrantyperiod=Integer.parseInt(request.getParameter("warranty_period"));
		javax.servlet.http.HttpSession adminsession=request.getSession(false);
	//int empid=(int) adminsession.getAttribute("adminid");
		
		org.hibernate.Session hibernatesession=HibernateUtilityHelper.getHibernateSession();
		
		Transaction tx=hibernatesession.beginTransaction();
		
		/*		RoleUtilityHelper roleutility=new RoleUtilityHelper();
		
		boolean ispriviledge=roleutility.manageroleprivilege(empid);
	
			
			
			  if(ispriviledge==true){*/
				  
				  String hql="UPDATE CRM_Products set "+"product_name=:pname,"+"warranty=:war "+"where product_id=:pid";
				  
				  Query queryinsert=hibernatesession.createSQLQuery(hql);
				  queryinsert.setString("pname", productname);
				  queryinsert.setInteger("war", warrantyperiod);
				  queryinsert.setInteger("pid", productid);
				  queryinsert.executeUpdate();
				  hibernatesession.close();
				 // tx.commit();
				  
				  RequestDispatcher rd=request.getRequestDispatcher("adminproductview.jsp");
				  rd.forward(request, response);
			/*  }else{
				  hibernatesession.close();
				  tx.commit();
				  PrintWriter pw=response.getWriter();
				  response.setContentType("text/html");  
					 pw.println("<script type=\"text/javascript\">");
					 pw.println("alert('Admin Updated');");
					 pw.println("location='adminproductview.jsp';");
					 pw.println("</script>");
					
			  }*/
			
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
