package com.crm.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Transaction;

import com.crm.models.CRM_Administrator;
import com.crm.models.CRM_Roles;
import com.crm.utility.HibernateUtilityHelper;

/**
 * Servlet implementation class GenerateRoleServlet
 */
@WebServlet("/GenerateRoleServlet")
public class GenerateRoleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GenerateRoleServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		boolean manage_customer=false;
		boolean manage_complaint=false;
		boolean pass_investigator=false;
		boolean escalate_priority=false;
		boolean solve_complaint=false;
		boolean close_complaint=false;
		boolean manage_roles=false;
		boolean view_customer_complaints=false;
		int employeeid=Integer.parseInt(request.getParameter("employeeid"));
		String rolename=request.getParameter("rolename");
		String managecustomer=request.getParameter("managecustomer");
		if(managecustomer!=null){
			
			 manage_customer=true;
		}
		String managecomplaint=request.getParameter("managecomplaint");
		if(managecomplaint!=null){
			
			manage_complaint=true;
		}
		String passinvestigator=request.getParameter("passinvestigator");
		if(passinvestigator!=null){
			
			pass_investigator=true;
		}
		String escalatepriority=request.getParameter("escalatepriority");
		if(escalatepriority!=null){
			
			escalate_priority=true;
		}
		String solvecomplaint=request.getParameter("solvecomplaint");
		if(solvecomplaint!=null){
			
			solve_complaint=true;
		}
		String closecomplaint=request.getParameter("closecomplaint");
		if(closecomplaint!=null){
			
			close_complaint=true;
		}
		String manageroles=request.getParameter("manageroles");
		if(manageroles!=null){
			
			manage_roles=true;
		}
		String viewcustomercomplaints=request.getParameter("viewcustomercomplaints");
		if(viewcustomercomplaints!=null){
			
			view_customer_complaints=true;
		}
		
		org.hibernate.Session hibernatesession=HibernateUtilityHelper.getHibernateSession();
		Transaction tx=hibernatesession.beginTransaction();
		//javax.servlet.http.HttpSession adminsession=request.getSession(false);
		CRM_Administrator admin=new CRM_Administrator();
		admin.setEmployee_id(employeeid);
		CRM_Roles roles=new CRM_Roles();
		roles.setRole_name(rolename);
		roles.setAdmin(admin);
		roles.setPriv_close_complaint(close_complaint);
		roles.setPriv_manage_complaints(manage_complaint);
		roles.setPriv_escalate_priority(escalate_priority);
		roles.setView_customer_complaint(view_customer_complaints);
		roles.setPriv_manage_roles(manage_roles);
		roles.setPriv_manage_customer(manage_customer);
		roles.setPriv_solve_complaint(solve_complaint);
		
		hibernatesession.save(roles);
		tx.commit();
		hibernatesession.close();
		RequestDispatcher rd=request.getRequestDispatcher("adminrolemanage.jsp");
		rd.forward(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
