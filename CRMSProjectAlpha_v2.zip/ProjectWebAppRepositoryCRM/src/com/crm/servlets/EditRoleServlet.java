package com.crm.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class EditRoleServlet
 */
@WebServlet("/EditRoleServlet")
public class EditRoleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditRoleServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		boolean manage_customer=false;
		boolean manage_complaint=false;
		boolean pass_investigator=false;
		boolean escalate_priority=false;
		boolean solve_complaint=false;
		boolean close_complaint=false;
		boolean manage_roles=false;
		boolean view_customer_complaints=false;
		int employeeid=Integer.parseInt(request.getParameter("employeeid"));
		String rolename=request.getParameter("rolename");
		String managecustomer=request.getParameter("managecustomer");
		if(managecustomer!=null){
			
			 manage_customer=true;
		}
		String managecomplaint=request.getParameter("managecomplaint");
		if(managecomplaint!=null){
			
			manage_complaint=true;
		}
		String passinvestigator=request.getParameter("passinvestigator");
		if(passinvestigator!=null){
			
			pass_investigator=true;
		}
		String escalatepriority=request.getParameter("escalatepriority");
		if(escalatepriority!=null){
			
			escalate_priority=true;
		}
		String solvecomplaint=request.getParameter("solvecomplaint");
		if(solvecomplaint!=null){
			
			solve_complaint=true;
		}
		String closecomplaint=request.getParameter("closecomplaint");
		if(closecomplaint!=null){
			
			close_complaint=true;
		}
		String manageroles=request.getParameter("manageroles");
		if(manageroles!=null){
			
			manage_roles=true;
		}
		String viewcustomercomplaints=request.getParameter("viewcustomercomplaints");
		if(viewcustomercomplaints!=null){
			
			view_customer_complaints=true;
		}
		
		org.hibernate.Session hibernatesession=HibernateUtilityHelper.getHibernateSession();
		Transaction tx=hibernatesession.beginTransaction();
		
		String hql="UPDATE CRM_Roles set "+"priv_manage_customer=:mancus,"+"priv_manage_complaints=:mancom,"+"priv_pass_investigator=:passinv,"+"priv_escalate_priority=:escpri,"+"priv_solve_complaint=:solcom,"+"priv_close_complaint=:clocom,"+"priv_manage_roles=:manrol,"+"view_customer_complaint=:vcuscom,"+"role_name=:rname "+"where emp_id=:eid";
		
		Query query=hibernatesession.executeSQLQuery(hql);
		query.setParameter("mancus",managecustomer);
		query.setParameter("mancom",managecomplaint);
		query.setParameter("passinv",passinvestigator);
		query.setParameter("escpri",escalatepriority);
		query.setParameter("solcom",solvecomplaint);
		query.setParameter("clocom",closecomplaint);
		query.setParameter("manrol",manageroles);
		query.setParameter("vcuscom",viewcustomercomplaints);
		query.setParameter("rname",rolename);
		query.setParameter("eid",employeeid);
		query.executeUpdate();
		hibernatesession.close();
		 RequestDispatcher rd=request.getRequestDispatcher("adminrolemanage.jsp");
		  rd.forward(request, response);
		
			
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
