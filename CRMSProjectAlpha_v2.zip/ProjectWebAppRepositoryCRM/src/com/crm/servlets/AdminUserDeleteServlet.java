package com.crm.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Query;
import org.hibernate.Transaction;

import com.crm.models.CRM_Users;
import com.crm.utility.HibernateUtilityHelper;

/**
 * Servlet implementation class AdminUserDeleteServlet
 */
@WebServlet("/AdminUserDeleteServlet")
public class AdminUserDeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminUserDeleteServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter pw=response.getWriter();
		int userid=Integer.parseInt(request.getParameter("userid"));
		org.hibernate.Session hibernatesession=HibernateUtilityHelper.getHibernateSession();
		Transaction tx =hibernatesession.beginTransaction();
		
		/*CRM_Users user=new CRM_Users();
		
		user.setUser_id(userid);*/
		
		String hql="delete from CRM_Users where user_id=:id";
		
		Query query=hibernatesession.createQuery(hql);
		query.setParameter("id", userid);
		query.executeUpdate();
		
		 response.setContentType("text/html");  
		 pw.println("<script type=\"text/javascript\">");
		 pw.println("alert('Admin Updated');");
		 pw.println("location='adminuserprofileview.jsp';");
		 pw.println("</script>");
		
		
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
