
		
		function Validate_username()
		{
		   var em=loginform.username.value;
		   
		  // var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		    if (em.length>10)
		     {
		    	loginform.username.focus();
		        alert('User name should not exceed 10 charecters');
		         
		         return;
		    }else if(em.length==0){
		    	loginform.username.focus();
		        alert('User name should not be blank');
		        return;
		    }
		}

		function Validate_fLetters(){
			var name=loginform.fname.value;
			if(name.trim()=="")
		    {
		     alert("name cannot be blank");
		     loginform.fname.focus();
		        return;
		    }
		   
		    if (!name.match(/^[a-zA-Z ]+$/)) 
		    {
		        alert("Only alphabets are allowed");
		        loginform.fname.focus();
		        return;
		    }

			}
		function Validate_lLetters(){
			var name=loginform.lname.value;
			if(name.trim()=="")
		    {
		     alert("name cannot be blank");
		     loginform.lname.focus();
		        return;
		    }
		   
		    if (!name.match(/^[a-zA-Z ]+$/)) 
		    {
		        alert("Only alphabets are allowed");
		        loginform.fname.focus();
		        return;
		    }

			}
		function Validate_password()
		{
		    var pwd=loginform.password.value;
		     if(pwd.trim()=="")
		    {
		    	 loginform.password.focus();
		         alert("Password cannot be blank");
		       
		        return;
		    }
		}

		function Validate_cpassword()
		{
		    var cpwd=loginform.cpassword.value;
		    var pwd=loginform.password.value;
		    if(cpwd.trim()=="")
		    {
		        alert("Confirm Password cannot be blank");
		        //cpassword.focus();
		        return;
		    }
		    if (cpwd!=pwd) 
		    {
		        alert('password did not match');
		        //cpassword.focus();
		        return;
		    }
		}

		function Validate_mail(){
			var em=loginform.email.value;
			   var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
			    if (!filter.test(em))
			     {
			        alert('Please provide a valid email address');
			         //email.focus();
			         return;
			    }

			}
		
		function Validate_address()
		{
		    var add=loginform.address.value;
		     if(add.trim()=="")
		    {
		        alert("Address cannot be blank");
		        
		        return;
		    }
		}

		function Validate_date()
		{
			var r=loginform.dob.value;
			re = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
			if(r!=''){
			if(regs=r.match(re))
				 {
				   if(regs[3]>1999 || regs[3]<1900)
					{
					
					  alert("invalid year"); 
					  return;
				    
				    }
					
				else{
					alert("valid year");
					return;
				    //fname.go.focus();
				     }
				  }
			else {
			        alert("Invalid date format: " );
			        return;
				 }
			}
		    else {
		    alert("Blank not allowed");
		  
		    return false;
		  }
		}
		
		function Validate_purchasedate()
		{
			var r=loginform.dop.value;
			var today=new Date();
			var dd=today.getDate();
			var mm=today.getMonth()+1;
			var yyyy=today.getFullYear();
			re = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
			if(r!=''){
			if(regs=r.match(re))
				 {
				   if(regs[3]<=yyyy)
					{
					   if(regs[1]<=mm){
						   if(regs[2]<dd){
							   alert("valid date");   
						   }
					   }
					    		
				    
				    }else{
					     alert("invalid date");}
				    //fname.go.focus();
					
				  }
			else {
			        alert("Invalid date format: " );
				 }
			}
		    else {
		    alert("Blank not allowed");
		  
		    return false;
		  }
		}

		function Validate_contact()
		{
		    var cont=loginform.phno.value;
		     if(!(cont.length==10 || (cont.match(/^[0-9]+$/)==true)))
		    {
		        alert("contact no is not valid");
		             // ad.focus();
		        return;
		    }else if(cont.length==0)
		    	{
		    	alert("contact no should not be blank");
		    	 return;
		    	}
		}
				
		
			
